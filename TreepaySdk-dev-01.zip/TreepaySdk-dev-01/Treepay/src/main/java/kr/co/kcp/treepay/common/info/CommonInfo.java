package kr.co.kcp.treepay.common.info;

public class CommonInfo
{
    public static final String OTT = "ott";
    public static final String OCT = "oct";
    public static final String SAVE_CARD = "save_card";
    public static final String CVV = "cvv";
    public static final String PACA = "PACA";
    public static final String PAOC = "PAOC";
    public static final int OCT_REQUEST_CODE = 100;
}
